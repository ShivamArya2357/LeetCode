package Practice.src.designpattern.strategy.ex1;

public interface SurgePricingBehaviour {

    public double getSurgePrice();
}
