package Practice.src.designpattern.strategy.ex1;

import java.util.Random;

public class HighSurgePricing implements SurgePricingBehaviour {

    @Override
    public double getSurgePrice() {
        return new Random(150).nextDouble();
    }
}
